<?php return array (
  'admin.alumni-list' => 'App\\Http\\Livewire\\Admin\\AlumniList',
  'admin.course-list' => 'App\\Http\\Livewire\\Admin\\CourseList',
  'admin.gallery-list' => 'App\\Http\\Livewire\\Admin\\GalleryList',
  'admin.user-list' => 'App\\Http\\Livewire\\Admin\\UserList',
  'alumni.submit-form' => 'App\\Http\\Livewire\\Alumni\\SubmitForm',
  'alumni.trace-list' => 'App\\Http\\Livewire\\Alumni\\TraceList',
  'event-list' => 'App\\Http\\Livewire\\EventList',
);