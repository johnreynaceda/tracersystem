<div class="ml-4 py-1">
    <img src="{{ Storage::url($getRecord()->image_path) }}" class="h-12 w-12 rounded-lg object-cover" alt="">
</div>
