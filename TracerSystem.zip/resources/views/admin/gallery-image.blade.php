<div class=" h-40">
    <img src="{{ Storage::url($getRecord()->gallery_path) }}" class="object-cover h-full rounded-lg" alt="">
</div>
