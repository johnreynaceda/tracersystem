<div>
    <div class="mb-4 flex justify-end items-center">
        <x-button label="EXPORT TO EXCEL" positive class="font-bold" right-icon="document-text" rounded />
    </div>
    {{ $this->table }}
</div>
