<div class="">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="cc90f1913b83d255b95be0e0fea6d576">
    Gender
</label>
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-secondary-300 focus:ring-primary-500 focus:border-primary-500" wire:model="gender" name="gender" id="cc90f1913b83d255b95be0e0fea6d576">
         <option selected hidden>Select An Option</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>     </select>

    
                </div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\TracerSystem\storage\framework\views/29557aa8959c3a248ea120bc4cb5d781.blade.php ENDPATH**/ ?>