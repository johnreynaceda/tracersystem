<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="28aa838315633f0e44049ce88de36803">
    Salary/Income
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="number" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" wire:model="salary" placeholder="" name="salary" id="28aa838315633f0e44049ce88de36803" />

            </div>

    
                </div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\TracerSystem\storage\framework\views/b5f0c6e9e7c98b688e5f98bc142c3d0c.blade.php ENDPATH**/ ?>