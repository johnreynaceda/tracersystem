<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\TracerSystem\resources\views/livewire/admin/course-list.blade.php ENDPATH**/ ?>