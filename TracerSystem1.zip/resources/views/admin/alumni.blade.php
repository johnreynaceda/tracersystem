@section('title', 'Alumni')
<x-admin-layout>
    <div>
        <livewire:admin.alumni-list />
    </div>
</x-admin-layout>
