@section('title', 'Course List')
<x-admin-layout>
    <div>
        <livewire:admin.course-list />
    </div>
</x-admin-layout>
