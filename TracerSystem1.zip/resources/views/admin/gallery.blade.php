@section('title', 'Gallery')
<x-admin-layout>
    <div>
        <livewire:admin.gallery-list />
    </div>
</x-admin-layout>
