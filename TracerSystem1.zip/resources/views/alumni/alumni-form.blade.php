<x-alumni-layout>
    <div class="">

        <section>
            <div class=" w-full">
                <livewire:alumni.submit-form />
            </div>
        </section>


    </div>
</x-alumni-layout>
