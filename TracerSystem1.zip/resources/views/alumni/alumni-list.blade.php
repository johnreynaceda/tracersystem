<x-alumni-layout>
    <div class="">

        <livewire:alumni.trace-list />


    </div>
</x-alumni-layout>
