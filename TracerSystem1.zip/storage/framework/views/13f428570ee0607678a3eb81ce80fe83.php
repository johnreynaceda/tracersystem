<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="faa1004b6baa01fbda972dae6d5a3937">
    Contact Number
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" wire:model="contact_number" placeholder="" name="contact_number" id="faa1004b6baa01fbda972dae6d5a3937" />

            </div>

    
                </div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\TracerSystem\storage\framework\views/fe5640659fbfbb733a2180abe3669bad.blade.php ENDPATH**/ ?>