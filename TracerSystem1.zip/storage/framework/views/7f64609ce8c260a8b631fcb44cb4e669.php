<div class=" h-40">
    <img src="<?php echo e(Storage::url($getRecord()->gallery_path)); ?>" class="object-cover h-full rounded-lg" alt="">
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\TracerSystem\resources\views/admin/gallery-image.blade.php ENDPATH**/ ?>