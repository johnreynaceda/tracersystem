@section('title', 'Events')
<x-admin-layout>
    <div>
        <livewire:event-list />
    </div>
</x-admin-layout>
