<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-positive-500 text-white bg-positive-500 hover:bg-positive-600 hover:ring-positive-600
    dark:ring-offset-slate-800 dark:bg-positive-700 dark:ring-positive-700
    dark:hover:bg-positive-600 dark:hover:ring-positive-600 font-bold">
    
    EXPORT TO EXCEL

            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
</svg>
    
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\TracerSystem\storage\framework\views/1fdc9a33852dff1837377181d645aaf4.blade.php ENDPATH**/ ?>