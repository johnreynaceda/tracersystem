<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full gap-x-2 text-sm px-4 py-2     ring-positive-500 text-white bg-positive-500 hover:bg-positive-600 hover:ring-positive-600
    dark:ring-offset-slate-800 dark:bg-positive-700 dark:ring-positive-700
    dark:hover:bg-positive-600 dark:hover:ring-positive-600">
    
    Save Event

    
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\TracerSystem\storage\framework\views/b7a995b73706d840a3e167ab4d9e6459.blade.php ENDPATH**/ ?>