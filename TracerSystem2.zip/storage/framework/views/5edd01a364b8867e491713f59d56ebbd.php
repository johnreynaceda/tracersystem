<div>
    <div class="mb-4 flex justify-end items-center">
        <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['label' => 'EXPORT TO EXCEL','spinner' => 'exportReport','rightIcon' => 'document-text','rounded' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['positive' => true,'class' => 'font-bold','wire:click' => 'exportReport']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
    </div>
    <?php echo e($this->table); ?>



    <?php if (isset($component)) { $__componentOriginal7ea8362733ae9e02c43079506217fb0f = $component; } ?>
<?php $component = WireUi\View\Components\Modal::resolve(['maxWidth' => '6xl'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'view_modal']); ?>

        <?php if (isset($component)) { $__componentOriginal526977d3da1dbf047bef54116d3416a0 = $component; } ?>
<?php $component = WireUi\View\Components\Card::resolve(['title' => 'Alumni Information'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="p-10">
                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <img src="<?php echo e(Storage::url($alumni_data->attachment ?? null)); ?>" class="w-full h-80"
                            alt="">
                    </div>
                    <div class="col-span-2 ">
                        <div class="df grid grid-cols-3 gap-5">
                            <div>
                                <span>Last Name</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->lastname ?? null); ?></p>
                            </div>
                            <div>
                                <span>First Name</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->firstname ?? null); ?></p>
                            </div>
                            <div>
                                <span>Middle Name</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->middlename ?? null); ?></p>
                            </div>
                            <div>
                                <span>Gender</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->gender ?? null); ?></p>
                            </div>
                            <div>
                                <span>Contact Number</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->contact_number ?? null); ?></p>
                            </div>
                            <div>
                                <span>Batch</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->batch ?? null); ?></p>
                            </div>
                            <div>
                                <span>3 Yeas Course</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->course ?? 'No Course'); ?></p>
                            </div>
                            <div>
                                <span>Short Term Course</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->short_course ?? 'No Course'); ?></p>
                            </div>
                            <div>
                                <span>Status</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->status ?? null); ?></p>
                            </div>
                            <div>
                                <span>Civil Status</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->civil_status ?? null); ?></p>
                            </div>
                            <div>
                                <span>Connected</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->connected ?? null); ?></p>
                            </div>
                            <div>
                                <span>Nationality</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->nationality ?? null); ?></p>
                            </div>
                            <div>
                                <span>Region</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->region ?? null); ?></p>
                            </div>
                            <div>
                                <span>Province</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->province ?? null); ?></p>
                            </div>
                            <div>
                                <span>City</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->city ?? null); ?></p>
                            </div>
                            <div>
                                <span>Barangay</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->barangay ?? null); ?></p>
                            </div>
                            <div>
                                <span>Street</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->street ?? null); ?></p>
                            </div>
                            <div>
                                <span>Employer</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->employer ?? null); ?></p>
                            </div>
                            <div>
                                <span>Date of Employment</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->doe ?? null); ?></p>
                            </div>
                            <div>
                                <span>Salary</span>
                                <p class="font-bold uppercase"><?php echo e($alumni_data->salary ?? null); ?></p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


             <?php $__env->slot('footer', null, []); ?> 

                <div class="flex justify-end gap-x-4">

                    <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['flat' => true,'label' => 'Cancel'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'close']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>


                </div>

             <?php $__env->endSlot(); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal526977d3da1dbf047bef54116d3416a0)): ?>
<?php $component = $__componentOriginal526977d3da1dbf047bef54116d3416a0; ?>
<?php unset($__componentOriginal526977d3da1dbf047bef54116d3416a0); ?>
<?php endif; ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ea8362733ae9e02c43079506217fb0f)): ?>
<?php $component = $__componentOriginal7ea8362733ae9e02c43079506217fb0f; ?>
<?php unset($__componentOriginal7ea8362733ae9e02c43079506217fb0f); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\TracerSystem\resources\views/livewire/admin/alumni-list.blade.php ENDPATH**/ ?>