<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full gap-x-2 text-base px-6 py-3     ring-negative-500 text-negative-500 border border-negative-500 hover:bg-negative-50
    dark:ring-offset-slate-800 dark:hover:bg-slate-700 px-4 uppercase font-bold">
    
    CLOSE

    
    </button>
